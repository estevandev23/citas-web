---
name: Clinical Trust
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#001428'
  on-primary: '#ffffff'
  primary-container: '#0f2942'
  on-primary-container: '#7991af'
  inverse-primary: '#b0c9e8'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00170c'
  on-tertiary: '#ffffff'
  tertiary-container: '#002e1d'
  on-tertiary-container: '#00a270'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a clinical, authoritative, and deeply empathetic environment engineered for mission-critical healthcare workflows and patient scheduling. Its visual language balances hospital-grade rigor with modern digital fluency, eliminating friction, anxiety, and cognitive overload.

The aesthetic philosophy is **Corporate Modern with High-Clarity Minimalism**:
- **Purity over Ornamentation:** Generous negative space, precise optical alignment, and disciplined restraint communicate diagnostic precision and trustworthiness.
- **Calm Authority:** Rich institutional navy anchors the visual plane, instilling a sense of safety and established medical protocol, while vibrant clinical blues direct critical interaction paths.
- **Accessible Humanity:** Soft contours, legible geometric typography, and gentle feedback states ensure patients in vulnerable emotional states feel guided and supported.

## Colors

The palette establishes an unambiguous hierarchy designed to maintain focus and convey operational health.

### Palette Architecture
- **Primary Canvas & Surfaces:** Absolute White (`#FFFFFF`) for elevated cards and modals; Slate Tint (`#F8FAFC`) for app shells and backgrounds to mitigate eye fatigue during extended clinical shifts.
- **Brand & Structural Core (`primary_color_hex` #0F2942):** Deep Institutional Navy used for high-level navigation, structural headers, high-impact branding, and critical modal confirmations.
- **Interactive Medical Blue (`secondary_color_hex` #2563EB):** Drives interactive elements, primary actionable flows (e.g., "Agendar cita"), active tabs, and focused input indicators.
- **Neutral Scale:** Foundation grounded in Slate (`#64748B`), with crisp surface dividers (`#E2E8F0`), secondary text (`#475569`), and deep text contrast (`#0F172A`).

### Semantic Color Engine
Clinical alerts avoid aggressive saturation, prioritizing dignified clarity:
- **Confirmado / Aprobado (`#10B981`):** Soft medical emerald for scheduled consultations, verified prescriptions, and successful check-ins. Background tint: `#ECFDF5`.
- **Pendiente / En Espera (`#F59E0B`):** Warm clinical amber for pending medical reviews, triages, or insurance validations. Background tint: `#FFFBEB`.
- **Cancelado / Rechazado (`#EF4444`):** Sobriquet crimson for missed sessions, cancellations, or contraindicated alerts. Background tint: `#FEF2F2`.
- **Reprogramación / Seguimiento (`#6366F1`):** Deep indigo for shifted bookings, doctor-initiated rescheduling, and recurring care plans. Background tint: `#EEF2FF`.

## Typography

Typography relies on **Plus Jakarta Sans**, chosen for its modern geometric architecture, open apertures, and clinical legibility across all viewport densities. 

### Editorial Guidelines
- **Spanish Medical Orthography:** The scale prioritizes elevated line-height values (1.5–1.65 on body text) to provide room for Spanish polysyllabic medical terminology, diacritical marks (tildes, acentos), and dense clinical notes.
- **Hierarchy Enforcement:** Section titles and specialty labels enforce medium to semibold weights; never use light weights for clinical data points, lab results, or dosage numbers.
- **Numbers and Timestamps:** Tabular figures are enforced for appointment hours, medical license identifiers, and blood pressure/triage readings to guarantee alignment across tabular views.

## Layout & Spacing

The layout is built on an **8pt modular baseline** and a responsive fluid grid system designed for high data density without visual overcrowding.

### Grid Rules
- **Desktop (1024px+):** 12-column grid, 24px (`1.5rem`) gutters, dynamic section margin up to 1280px max-width container. Dashboard multi-pane views utilize a fixed 280px clinical sidebar and fluid right content container.
- **Tablet (768px – 1023px):** 8-column grid, 20px gutters, 24px margins. Navigation collapses into a slim rail or clinical drawer.
- **Mobile (<768px):** 4-column grid, 16px (`1rem`) gutters, 16px (`1rem`) page margins. Sticky bottom action sheets replace complex modal windows to allow one-handed appointment confirmation.

### Spacing Discipline
- `space-xs` (4px) and `space-sm` (8px) govern tight pairings: icons with their accompanying text, badge internal padding, and form input label relationships.
- `space-md` (16px) establishes standard card internal padding and form field stack distance.
- `space-lg` (24px) defines inter-card intervals and clinical filter bar separations.
- `space-xl` (40px) anchors macro-level section gaps.

## Elevation & Depth

This system avoids dramatic dropshadows and heavy skeuomorphic shading, adhering strictly to **Tonal Layering with Ethereal Soft Shadows**.

### Layering Model
- **Base Level (`L0`):** Background body layer `#F8FAFC`. Zero elevation.
- **Surface Level (`L1`):** Main interactive cards, calendars, and clinical records resting on `#FFFFFF`. Structured with a precise 1px outline: `border: 1px solid #E2E8F0`. Shadow: `0 1px 3px 0 rgba(15, 41, 66, 0.04), 0 1px 2px -1px rgba(15, 41, 66, 0.02)`.
- **Hover & Focused Cards (`L2`):** `0 10px 15px -3px rgba(15, 41, 66, 0.06), 0 4px 6px -4px rgba(15, 41, 66, 0.03)`. The border shifts subtly to `#CBD5E1`.
- **Floating Overlays & Menus (`L3`):** Time slot pickers, dropdown selects, and flyout navigation: `0 20px 25px -5px rgba(15, 41, 66, 0.08), 0 8px 10px -6px rgba(15, 41, 66, 0.04)`.
- **Modal Dialogs & Critical Alerts (`L4`):** Emergency reschedule modals, diagnostic dialogs: `0 25px 50px -12px rgba(15, 41, 66, 0.16)` with a backdrop blur overlay of `background: rgba(15, 41, 66, 0.4); backdrop-filter: blur(4px)`.

## Shapes

The geometric architecture relies on balanced, softened radii (Level 2) that reconcile institutional credibility with a gentle, non-threatening patient experience.

### Radius Metrics
- **Small Controls (8px / `0.5rem`):** Applied to form inputs, search fields, inner status tags, segmented slot buttons, and pagination controls.
- **Medium Panels & Cards (12px / `0.75rem`):** The primary radius across doctor profiles, appointment review cards, and medical summary tiles.
- **Large Contexts & Modals (16px / `1rem`):** High-level booking containers, slide-in triage panes, and desktop modal containers.
- **Pill/Full (9999px):** Strictly reserved for status badges (`Confirmado`, `En Espera`, `Urgente`), doctor availability tags ("Hoy", "Mañana"), and circular avatar frames.

## Components

### Buttons & Action Controls
- **Primary Button ("Confirmar Cita"):** Solid `#2563EB` fill, white text, 8px border-radius, font weight 600. Hover state darkens to `#1D4ED8`. Active state deepens to `#1E40AF`.
- **Secondary / Institutional Action ("Guardar Historial"):** Deep Navy `#0F2942` fill with white text, utilized for master administrative actions and final triage submissions.
- **Outline Button:** Border of 1px `#E2E8F0`, transparent background, text `#0F2942`. On hover: surface tints to `#F8FAFC` and border shifts to `#CBD5E1`.
- **Ghost/Tertiary:** No border, text `#2563EB`. Used for "Volver", "Ver más detalles", or low-priority actions.

### Badges & Status Chips
- **Structural Spec:** Height 24px, padding 2px 10px, radius 9999px (pill), text font-size 12px, font-weight 600.
- **Estado Confirmado:** Background `#ECFDF5`, text `#065F46`, 1px solid `#A7F3D0`. Prefixed with a 6px solid emerald dot.
- **Estado Pendiente:** Background `#FFFBEB`, text `#92400E`, 1px solid `#FDE68A`. Prefixed with an amber dot.
- **Estado Cancelado:** Background `#FEF2F2`, text `#991B1B`, 1px solid `#FECACA`.
- **Estado Reprogramado:** Background `#EEF2FF`, text `#3730A3`, 1px solid `#C7D2FE`.

### Input Fields & Search Bars
- **Text Inputs:** Height 44px (touch-compliant), 8px radius, border 1px solid `#E2E8F0`, background `#FFFFFF`, text `#0F172A`. Placeholder text `#94A3B8`.
- **Focus State:** Border color shifts to `#2563EB`, paired with a 3px ring glow in `rgba(37, 99, 235, 0.12)`. No harsh browser outlines.
- **Medical Specialty Search Bar:** Includes a left-aligned search icon in `#64748B`, an inline category chip, and an instant autocomplete dropdown layer (`L3`).

### Appointment Cards (Tarjetas de Citas)
- **Container:** Background `#FFFFFF`, 12px radius, 1px border `#E2E8F0`, elevation `L1`.
- **Structure:** 
  - *Header:* Specialty tag and semantically colored status chip.
  - *Body:* Doctor avatar (48px, circular), name (Semibold 16px `#0F172A`), specialty (Regular 14px `#64748B`), and hospital/clinic location with pin icon.
  - *Footer:* Distinct background separator (`#F8FAFC`), containing the date/time chip (Calendar icon + "14 Oct, 10:30 AM") and quick-action buttons ("Reprogramar", "Ver Ficha").

### Multi-Step Flow Indicator (Indicador de Flujo por Pasos)
- Horizontal step timeline with numeric nodes (32px circular).
- **Completed Step:** Background `#10B981`, checkmark icon, connecting bar filled in `#10B981`.
- **Active Step:** Background `#2563EB`, white step number, ring glow in `rgba(37, 99, 235, 0.2)`. Label is semibold `#0F2942`.
- **Upcoming Step:** Background `#FFFFFF`, border 2px solid `#E2E8F0`, text `#94A3B8`. Connecting bar stays `#E2E8F0`.

### Selection Controls (Checkboxes & Radios)
- Checkboxes feature an 8px radius for soft accessibility. Radios are 18px circles.
- Inactive state: 1.5px solid border `#CBD5E1`.
- Active state: Background `#2563EB`, inner white checkmark or center dot.